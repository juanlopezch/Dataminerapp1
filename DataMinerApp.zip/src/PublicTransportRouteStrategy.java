
public class PublicTransportRouteStrategy implements RouteStrategy {
    public String buildRoute(String A, String B) {
        return "Route by public transport from " + A + " to " + B;
    }
}
