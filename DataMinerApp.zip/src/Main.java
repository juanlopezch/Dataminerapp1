
public class Main {
    public static void main(String[] args) {
        System.out.println("=== TEMPLATE METHOD ===");
        DataMiner docMiner = new DocDataMiner();
        docMiner.mine("docfile.doc");

        DataMiner csvMiner = new CsvDataMiner();
        csvMiner.mine("data.csv");

        DataMiner pdfMiner = new PdfDataMiner();
        pdfMiner.mine("file.pdf");

        System.out.println("\n=== STRATEGY ===");
        Navigator navigator = new Navigator();

        navigator.setStrategy(new CarRouteStrategy());
        navigator.buildRoute("A", "B");

        navigator.setStrategy(new PublicTransportRouteStrategy());
        navigator.buildRoute("A", "B");

        navigator.setStrategy(new WalkingRouteStrategy());
        navigator.buildRoute("A", "B");
    }
}
