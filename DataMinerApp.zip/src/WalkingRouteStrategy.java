
public class WalkingRouteStrategy implements RouteStrategy {
    public String buildRoute(String A, String B) {
        return "Route by walking from " + A + " to " + B;
    }
}
