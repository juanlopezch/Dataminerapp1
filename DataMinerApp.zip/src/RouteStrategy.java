
public interface RouteStrategy {
    String buildRoute(String A, String B);
}
