
public class Navigator {
    private RouteStrategy strategy;

    public void setStrategy(RouteStrategy strategy) {
        this.strategy = strategy;
    }

    public void buildRoute(String A, String B) {
        System.out.println(strategy.buildRoute(A, B));
    }
}
