
public abstract class DataMiner {
    public final void mine(String path) {
        String file = openFile(path);
        String rawData = extractData(file);
        String data = parseData(rawData);
        String analysis = analyzeData(data);
        sendReport(analysis);
        closeFile(file);
    }

    protected abstract String openFile(String path);
    protected abstract String extractData(String file);
    protected abstract String parseData(String rawData);
    protected abstract String analyzeData(String data);
    protected abstract void sendReport(String analysis);
    protected abstract void closeFile(String file);
}
