
public class PdfDataMiner extends DataMiner {
    protected String openFile(String path) {
        return "PDF file opened: " + path;
    }

    protected String extractData(String file) {
        return "Extracted PDF data from " + file;
    }

    protected String parseData(String rawData) {
        return "Parsed PDF data: " + rawData;
    }

    protected String analyzeData(String data) {
        return "Analyzed PDF data: " + data;
    }

    protected void sendReport(String analysis) {
        System.out.println("PDF Report: " + analysis);
    }

    protected void closeFile(String file) {
        System.out.println("Closed PDF file: " + file);
    }
}
