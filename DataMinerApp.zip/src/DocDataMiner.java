
public class DocDataMiner extends DataMiner {
    protected String openFile(String path) {
        return "DOC file opened: " + path;
    }

    protected String extractData(String file) {
        return "Extracted DOC data from " + file;
    }

    protected String parseData(String rawData) {
        return "Parsed DOC data: " + rawData;
    }

    protected String analyzeData(String data) {
        return "Analyzed DOC data: " + data;
    }

    protected void sendReport(String analysis) {
        System.out.println("DOC Report: " + analysis);
    }

    protected void closeFile(String file) {
        System.out.println("Closed DOC file: " + file);
    }
}
