
public class CarRouteStrategy implements RouteStrategy {
    public String buildRoute(String A, String B) {
        return "Route by car from " + A + " to " + B;
    }
}
